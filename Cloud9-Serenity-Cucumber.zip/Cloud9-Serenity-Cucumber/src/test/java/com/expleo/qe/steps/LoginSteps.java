package com.expleo.qe.steps;

import com.expleo.qe.pages.LoginPageObject;
import net.thucydides.core.annotations.Step;

public class LoginSteps {

    LoginPageObject loginPage;

    @Step("Open the browser")
    public void openBrowser(){
        loginPage.openTheBrowser();

    }

    @Step("Captured Details\n Email Address: {0}\nPassword: {1}")
    public void loginDetails(String email, String password) {

        try {
            loginPage.enterEmail(email);
            loginPage.enterPassword(password);
            Thread.sleep(5000);
            loginPage.clickSigninButton();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Step("{0}")
    public void checkLoginSuccessFul(String message){}
}
