package com.expleo.qe.pages;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class AddBookingPageObject extends PageObject {

    @FindBy(css = "[href='bookflight.html']")
    WebElement btnBook;

    @FindBy(name = "Origin")
    private WebElement selOrigin;

    @FindBy(name = "Destination")
    private WebElement selDestination;

    @FindBy(id = "seat")
    private WebElement seat;


    private WebElement Flightclass;
    private WebElement submitbutton;

    public void clickBook(){
        btnBook.click();
    }

    public void setSelOrigin(String origin){
        Select select=new Select(selOrigin);
        select.selectByVisibleText(origin);
    }

    public void setSelDestination(String destination){
        Select select=new Select(selDestination);
        select.selectByVisibleText(destination);
    }

    public void setSeat(String _seat){
        seat.clear();
        seat.sendKeys(_seat);
    }

    public void setFlightClass(String flightClass){
        Select select=new Select(Flightclass);
        select.selectByVisibleText(flightClass);
    }

    public void clickBtnBook(){
        submitbutton.click();
    }





}
