package com.expleo.qe.stepdefinitions;

import com.expleo.qe.pages.AddBookingPageObject;
import com.expleo.qe.pages.LoginPageObject;
import com.expleo.qe.pages.NavigationPageObect;
import com.expleo.qe.steps.AddBookingSteps;
import com.expleo.qe.steps.LoginSteps;
import com.expleo.qe.steps.NavigationSteps;
import cucumber.api.java.After;
import cucumber.api.java.en.*;
import net.thucydides.core.annotations.Steps;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class Cloud9_StepDefinitions {

    @Steps
    LoginSteps loginSteps;
    @Steps
    AddBookingSteps addBooking;
    @Steps
    NavigationSteps navigation;
    @Given("^That I am on the Cloud(\\d+) home page$")
    public void that_I_am_on_the_Cloud_home_page(int arg1) {
        loginSteps.openBrowser();
        NavigationPageObect.confirmHomePage();
    }

    @When("^log in with valid user id and password$")
    public void log_in_with_valid_user_id_and_password() {
        loginSteps.loginDetails("pfarelo.mashau@sqs.com","Pfarzo@73273");
    }

    @Then("^I will be take to the itinerary page$")
    public void i_will_be_take_to_the_itinerary_page() {

        loginSteps.checkLoginSuccessFul(NavigationPageObect.checkLoginSuccessful());
        //navigation.logout();
    }

    @Given("^I navigate to the booking page$")
    public void iNavigateToTheBookingPage() {
        addBooking.INavigateToTheBookingPage();
        NavigationPageObect.checkBookingPage();
    }

    @When("^I add a valid booking$")
    public void iAddAValidBooking() {
        addBooking.IAddAValidBooking("Johannesburg","Durban","F1020","Business");
    }

    @Then("^My booking is successful$")
    public void myBookingIsSuccessful() {
        addBooking.bookingStatus(NavigationPageObect.checkBookingSuccessful());
    }

    @After
    public void teardown() throws InterruptedException {
        Thread.sleep(3000);
        navigation.logout();
        NavigationPageObect.confirmHomePage();
    }
}
