package com.expleo.qe.pages;

import net.serenitybdd.core.pages.PageObject;
import org.hamcrest.core.Is;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class NavigationPageObect extends PageObject {

    @FindBy(linkText = "Logout")
    private WebElement btnLogout;

    @FindBy(css = "[href='bookflight.html']")
    private static WebElement btnBookFlight;

    @FindBy(css = "[href='itinerary.php']")
    private static WebElement btnItinerary;

    @FindBy(xpath = "/html/body/div/div/div[2]/h2/center")
    private static WebElement msgBookingSuccessful;

    @FindBy(xpath = "/html/body/div/div/div[2]/h1")
    private static WebElement lblBookFlight;

    @FindBy(xpath = "/html/body/div/div/div[2]/h1")
    private static WebElement lblItinerary;

    @FindBy(xpath = "/html/body/div/form/h2/center")
    private static WebElement lblHome;


    public void logout1(){
        btnLogout.click();
    }

    public static String checkBookingSuccessful(){
        String expected="Flight booked successfully";
        String actual=msgBookingSuccessful.getText();

        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
            expected+=" does not match the booking message";
        }
        return expected;
    }

    public static String checkBookingPage(){
        String expected="Book Flight";
        String actual=lblBookFlight.getText();

        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
            expected+=" does not match the booking message";
        }
        return expected;
    }

    public static String checkLoginSuccessful(){
        String expected="Itinerary";
        String actual=lblItinerary.getText();
        try{
            assertThat(actual, Is.is(equalTo(expected)));
        }catch (AssertionError e){
            expected+=" does not match the login page label";
        }
        return expected;
    }

    public static String confirmHomePage(){
        String expected="Cloud9 - Sign in",actual=lblHome.getText();
        try{
            assertThat(actual,is(equalTo(expected)));
        }catch (AssertionError e){
            expected+=" Not Found";
        }
        return expected;
    }
}
