package com.expleo.qe.steps;

import com.expleo.qe.pages.AddBookingPageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;

public class AddBookingSteps {

    AddBookingPageObject addBooking;

    @Step("Navigate to booking")
    public void INavigateToTheBookingPage(){
        addBooking.clickBook();
    }

    @Step("Provide valid booking Details\n Origin: {0}\nDestination: {1}\nSeat: {2}\nClass: {3}\n")
    public void IAddAValidBooking(String origin,String destination,String fSeat,String fClass){
        try{
            addBooking.setSelOrigin(origin);
            addBooking.setSelDestination(destination);
            addBooking.setSeat(fSeat);
            addBooking.setFlightClass(fClass);
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        addBooking.clickBtnBook();
    }

    @Step("Status: {0}")
    public void bookingStatus(String message){}
}
