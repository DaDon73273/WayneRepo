package com.expleo.qe.steps;

import com.expleo.qe.pages.NavigationPageObect;
import net.thucydides.core.annotations.Step;

public class NavigationSteps {
    NavigationPageObect navigate;

    @Step("Now we are login out")
    public void logout(){
        navigate.logout1();
    }
}
